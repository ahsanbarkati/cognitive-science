# cognitive-science

There are two files for each question. One is the python notebook file which needs to be run on the jupyter notebook (For a better illustration of plots and environment).
Second file is simple py file which can be run using python. I would request you to please test it using the notebook since I have organised the codes very well there. 
